# fun

[![Build Status](https://travis-ci.com/yihui/fun.svg)](https://travis-ci.com/yihui/fun)
[![Downloads from the RStudio CRAN mirror](https://cranlogs.r-pkg.org/badges/fun)](https://cran.r-project.org/package=fun)

This is a collection of R games and other funny stuff, such as the classic
Mine sweeper and sliding puzzles.
