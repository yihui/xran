# xfun

[![Build Status](https://travis-ci.com/yihui/xfun.svg)](https://travis-ci.com/yihui/xfun)
[![Coverage status](https://codecov.io/gh/yihui/xfun/branch/master/graph/badge.svg)](https://codecov.io/github/yihui/xfun?branch=master)
[![CRAN release](https://www.r-pkg.org/badges/version/xfun)](https://cran.r-project.org/package=xfun)

This package contains several utility functions that I frequently use in other packages, and also miscellaneous functions that I use by myself from time to time. For more information, see https://yihui.org/xfun/.
