#' A hello function
#'
#' Prints \code{Hello World!}.
#'
#' This function was written in R/hello.R, and all other functions in this
#' package were written in R Markdown documents.
#' @export
#' @examples rlp::hello()
hello = function() {
  cat("Hello, world!\n")
}
