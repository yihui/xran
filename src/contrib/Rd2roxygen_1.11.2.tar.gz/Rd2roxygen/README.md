# Rd2roxygen

[![Build Status](https://travis-ci.org/yihui/Rd2roxygen.svg)](https://travis-ci.org/yihui/Rd2roxygen)
[![Downloads from the RStudio CRAN mirror](https://cranlogs.r-pkg.org/badges/Rd2roxygen)](https://cran.r-project.org/package=Rd2roxygen)

Convert Rd to roxygen documentation. For more information, see <https://yihui.org/Rd2roxygen>.

