# CHANGES IN MSG VERSION 0.6


# CHANGES IN MSG VERSION 0.5

- Moved a lot of example code from the MSG book to this package, and added a function `msg()` to run these examples (thanks, Peng Zhao).

# CHANGES IN MSG VERSION 0.4

- Fixed a few broken demos thanks to Peng Zhao and Xiangyun Huang.

# CHANGES IN MSG VERSION 0.3

- Tweaks to pass `R CMD check`.

# CHANGES IN MSG VERSION 0.2.2

- Demos no longer use non-ASCII characters.

# CHANGES IN MSG VERSION 0.2

- Updated the quake6 examples to work with ggplot 0.9.

# CHANGES IN MSG VERSION 0.1-0

- The first version of the MSG package.
