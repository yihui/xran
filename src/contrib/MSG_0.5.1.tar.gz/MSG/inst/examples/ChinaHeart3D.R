# 中国心
demo("ChinaHeart3D", package = "fun")
