# 加州伯克利分校录取数据四瓣图
fourfoldplot(UCBAdmissions, mfcol = c(2, 3)) # 2 行 3 列排版
