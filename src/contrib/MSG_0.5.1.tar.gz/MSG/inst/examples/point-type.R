# 点的类型
demo("pointTypes", package = "MSG")
