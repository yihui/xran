# 回归模型中边际分布的展示
demo("layout_margin", package = "MSG")
