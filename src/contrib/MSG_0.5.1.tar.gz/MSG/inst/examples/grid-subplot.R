# 用 grid 包实现的图形局部放大效果
demo("subplot", package = "MSG")
