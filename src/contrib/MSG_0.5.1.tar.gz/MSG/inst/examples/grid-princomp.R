# 基于旋转坐标系的主成分分析示意图
demo("princomp", package = "MSG")
