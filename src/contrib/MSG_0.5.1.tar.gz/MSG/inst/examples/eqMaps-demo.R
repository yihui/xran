# 在卫星地图上标记地震发生的地点和震级
demo("eqMaps", package = "MSG")
