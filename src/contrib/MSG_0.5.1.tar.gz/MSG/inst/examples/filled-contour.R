# 火山高度数据颜色等高图
demo("volcano", package = "MSG")
