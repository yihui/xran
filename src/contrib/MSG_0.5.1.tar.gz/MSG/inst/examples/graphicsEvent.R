# 鼠标在图形窗口中移动的效果图
demo("mouse_move", package="MSG")
