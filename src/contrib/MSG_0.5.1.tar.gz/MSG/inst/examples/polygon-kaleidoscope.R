# 用多边形生成的万花筒
demo("kaleidoscope", package = "MSG")
