# 在统计学的轨道中
demo("signSTAT", package = "MSG")
