# 梯度下降算法的过程演示
demo("gradArrows1", package = "MSG")
