# 函数 `layout()` 的版面设置示意图
layout(matrix(c(1, 2, 1, 3), 2), c(1, 3), c(1, 2))
layout.show(3)
