# 世界各国农业进出口竞争力地图
source(system.file("extdata", "AgriComp.R", package = "MSG"))
demo("AgriComp", package = "MSG")
