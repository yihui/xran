# pollen 数据中暗藏的特征
demo("rgl_animation", package = "animation")
