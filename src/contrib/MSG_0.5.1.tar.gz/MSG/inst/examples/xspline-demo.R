# X-样条各种形状的展示
demo("xsplineDemo", package = "MSG")
